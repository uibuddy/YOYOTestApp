﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace testApp1.Models
{
    public class Players
    {
        public int Id
        {
            get;
            set;
        }
        public string PlayerName
        {
            get;
            set;
        }
        public string IsWarned
        {
            get;
            set;
        }
        public string IsStopped
        {
            get;
            set;
        }
        public string ShuttleLavel
        {
            get;
            set;
        }
        public string ShuttleNo
        {
            get;
            set;
        }
        public string TotalTime
        {
            get;
            set;
        }
        public string TotalDistance
        {
            get;
            set;
        }


    }
}
