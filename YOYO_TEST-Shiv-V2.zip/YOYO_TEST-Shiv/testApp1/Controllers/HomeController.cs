﻿using System.Collections.Generic;
using System.Linq;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using testApp1.Models;

namespace testApp1.Controllers
{
    public class HomeController : Controller
    {
        List<Players> playersList = new List<Players>();
        JSONReadWrite readWrite = new JSONReadWrite();

        public IActionResult Index() {
           
            playersList = JsonConvert.DeserializeObject<List<Players>>(readWrite.Read("players.json", "data"));
            return View(playersList);
        }

        [HttpPost]
        public IActionResult UpdatePlayerStatus(Players playerModel)
        {
            playersList = JsonConvert.DeserializeObject<List<Players>>(readWrite.Read("players.json", "data"));
            Players player = playersList.FirstOrDefault(x => x.Id == 3);

            if (player == null)
            {
                playersList.Add(playerModel);
            }
            else
            {
                int index = playersList.FindIndex(x => x.Id == playerModel.Id);
                playersList[index] = playerModel;
            }

            string jSONString = JsonConvert.SerializeObject(playersList);
            readWrite.Write("players.json", "data", jSONString);

            return PartialView("_ViewTable", playersList);

        }

        [HttpPost]
         public IActionResult Delete(int id)
         {
            playersList = JsonConvert.DeserializeObject<List<Players>>(readWrite.Read("players.json", "data"));
            int index = playersList.FindIndex(x => x.Id == id);
            playersList.RemoveAt(index);

            string jSONString = JsonConvert.SerializeObject(playersList);
            readWrite.Write("players.json", "data", jSONString);

            return PartialView("_ViewTable", playersList);

        }

        [HttpPost]
        public IActionResult GetActivePlayers()
        {
            playersList = JsonConvert.DeserializeObject<List<Players>>(readWrite.Read("players.json", "data"));
            int index = playersList.FindIndex(x => x.IsStopped == "false");
            return Content(index.ToString());
        }

        [HttpPost]
        public IActionResult GetShuttles()
        {
            string Shuttles = readWrite.Read("fitnessrating_beeptest.json", "data");
            return Content(Shuttles);
        }

    }
}
