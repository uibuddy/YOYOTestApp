﻿/*
 
 DOM manuplation Javascript function for counter and handle API

 */

var shuttleObjectList = [];
var timeCounter = 0;
var TotalTime = 0;
var TotalDistance = 0;
var NextShuttleTime = 0;
var Label = 0;
var Shuttle = 0;
var Speed = 0;

var setTimeoutCounter;
var total_distance = 0;
var total_time = 0;

$(function () {
    $('#listOfPlayers').removeClass('is--race-started');
});

function toggleEditor(e) {
    $('.shuttle_info-editor').hide();
    $(e).parent().parent().find('.shuttle_info-editor').toggle();
}

function checkActivePlayers() {
    $.post("/Home/GetActivePlayers/", function (index) {
        if (parseInt(index) < 0) {
            stopTimer();
            $('#listOfPlayers').removeClass('is--race-started');
            $('#listOfPlayers').addClass('is--race-completed');
            $('.race-result').html('<button type="button" class="btn btn-success">View Result</button>');
            $('.shuttle-label').html('<b> Completed !</b>');
            $("progress").val(100);
            $('.horizontal-progress-bar label').html("<b>Race Completed!</b>");
            console.log('data needed to reset: ');
        }                  
    });
};

function updatePlayerStatus(e, id, status, model) {
    var updatedModel = {},
        shuttleLabel = $('.speed_label').text(),
        shuttleNumber = $('.shuttle_no').text(),
        totalTime = $('.total-time').text(),
        totalDistance = $('.total-distance').text();

    if (status === "warned") {
        updatedModel = { "Id": model.Id, "PlayerName": model.PlayerName, "IsWarned": "true", "IsStopped": model.IsStopped, "ShuttleLavel": shuttleLabel, "ShuttleNo": shuttleNumber, "TotalTime": totalTime, "TotalDistance": totalDistance };
    }
    if (status === "stopped") {
        updatedModel = { "Id": model.Id, "PlayerName": model.PlayerName, "IsWarned": model.IsWarned, "IsStopped": "true", "ShuttleLavel": shuttleLabel, "ShuttleNo": shuttleNumber, "TotalTime": totalTime, "TotalDistance": totalDistance };
    }
    if (status === "shuttleInfo") {
        var sh_Label = $(e).parent().find('.sh_label').val();
        var sh_Number = $(e).parent().find('.sh_number').val();
        updatedModel = { "Id": model.Id, "PlayerName": model.PlayerName, "IsWarned": model.IsWarned, "IsStopped": model.IsStopped, "ShuttleLavel": sh_Label, "ShuttleNo": sh_Number, "TotalTime": model.TotalTime, "TotalDistance": model.TotalDistance };
     }       
    var url = "/Home/UpdatePlayerStatus/";
    $.post(url, playerModel = updatedModel)
        .done(function (response) {
            $("#listOfPlayers").html(response);
        }).then(function () {
            if (status === "stopped")
            checkActivePlayers();
        });
}


// UI functions


function parsingShuttleInfo(shuttleObj, nextShuttleObj) {
    $('.speed_label').text(shuttleObj.SpeedLevel);
    $('.shuttle_no').text(shuttleObj.ShuttleNo);
    $('.speed').text(shuttleObj.Speed);

    total_distance = parseInt(shuttleObj.AccumulatedShuttleDistance);
    total_time = total_time + parseInt(shuttleObj.LevelTime);

    $('.total-time').text(total_time);
    $('.total-distance').text(total_distance);
    $('.nextShuttle-time').text(nextShuttleObj.LevelTime);

    $("#item_ShuttleLavel").val(100);
    $('.label-inputBox').each(function (i, el) {
        $('.label-inputBox').val(shuttleObj.SpeedLevel);
    });
}


function readingShuttle(shuttleObj) {
    var i = 0;
    var timer = 0;

    
    function myLoop() {
        parsingShuttleInfo(shuttleObj[i], shuttleObj[i]);
        if (i < 100) {
            $("progress").val(10 + (i * 4));//css("width", i + "%").text(i + " %");           
        }
       setTimeoutCounter= setTimeout(function () {
            i++;
            if (i < shuttleObj.length) {
                myLoop();
            }
        }, parseInt(shuttleObj[i].LevelTime) * 1000);        
    }
    myLoop();
    
}
function stopTimer() {
    if (setTimeoutCounter) {
        clearTimeout(setTimeoutCounter);
    }
}
function startRace() {
    $('#listOfPlayers').addClass('is--race-started');
    $.post("/Home/GetActivePlayers/", function (index) {       
            if (parseInt(index) < 0) {
                alert('New Players not found!,To restart race please reset player records');
                return false;
            } else {               
                $('.circle_progress-bar').removeClass('ideal');
                $('.circle_progress-bar').addClass('running');
                $.post("/Home/GetShuttles", function (data) {
                    readingShuttle(JSON.parse(data));
                    shuttleObjectList = JSON.parse(data);
                });
            }
        });    
    
   

}
